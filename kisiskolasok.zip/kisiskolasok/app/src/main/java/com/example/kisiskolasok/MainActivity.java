package com.example.kisiskolasok;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    EditText minSzam, maxSzam, valasz;
    TextView kerdesText, eredmenyText, visszajelzesText;
    Button ellenorizBtn, ujraBtn;

    int a, b;
    int kerdesSzam = 0;
    int helyes = 0;
    int helytelen = 0;

    Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        minSzam = findViewById(R.id.minSzam);
        maxSzam = findViewById(R.id.maxSzam);
        valasz = findViewById(R.id.valasz);

        kerdesText = findViewById(R.id.kerdesText);
        eredmenyText = findViewById(R.id.eredmenyText);
        visszajelzesText = findViewById(R.id.visszajelzesText);

        ellenorizBtn = findViewById(R.id.ellenorizBtn);
        ujraBtn = findViewById(R.id.ujraBtn);

        ujraBtn.setVisibility(View.GONE);

        ellenorizBtn.setOnClickListener(v -> ellenoriz());
        ujraBtn.setOnClickListener(v -> ujra());
    }


    void ujKerdes() {
        int min = Integer.parseInt(minSzam.getText().toString());
        int max = Integer.parseInt(maxSzam.getText().toString());

        a = random.nextInt(max - min + 1) + min;
        b = random.nextInt(max - min + 1) + min;

        kerdesText.setText(a + " × " + b + " = ?");
        valasz.setText("");
    }


    void ellenoriz() {


        if (kerdesSzam == 0) {
            ujKerdes();
            kerdesSzam++;
            return;
        }

        if (valasz.getText().toString().isEmpty()) {
            return;
        }

        int beirt = Integer.parseInt(valasz.getText().toString());

        if (beirt == a * b) {
            helyes++;
            visszajelzesText.setText("Ügyes vagy!");
            visszajelzesText.setTextColor(Color.parseColor("#2E7D32")); // zöld
        } else {
            helytelen++;
            visszajelzesText.setText("Ez most nem sikerült");
            visszajelzesText.setTextColor(Color.parseColor("#C62828")); // piros
        }

        kerdesSzam++;

        if (kerdesSzam > 6) {
            eredmenyText.setText(
                    "Játék vége!\n" +
                            "Helyes válaszok: " + helyes + "\n" +
                            "Helytelen válaszok: " + helytelen
            );
            ellenorizBtn.setEnabled(false);
            ujraBtn.setVisibility(View.VISIBLE);
        } else {
            ujKerdes();
        }
    }


    void ujra() {
        kerdesSzam = 0;
        helyes = 0;
        helytelen = 0;

        kerdesText.setText("");
        eredmenyText.setText("");
        visszajelzesText.setText("");

        ellenorizBtn.setEnabled(true);
        ujraBtn.setVisibility(View.GONE);
    }
}
